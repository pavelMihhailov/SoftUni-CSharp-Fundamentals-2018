﻿namespace BashSoft.Attributes
{
    using System;

    [AttributeUsage(AttributeTargets.Field)]
    public class InjectAttribute : Attribute
    {
        public InjectAttribute()
        {
        }
    }
}
