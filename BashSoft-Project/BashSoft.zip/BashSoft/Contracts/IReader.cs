﻿namespace BashSoft.Contracts
{
    public interface IReader
    {
        void StartReadingCommands();
    }
}
