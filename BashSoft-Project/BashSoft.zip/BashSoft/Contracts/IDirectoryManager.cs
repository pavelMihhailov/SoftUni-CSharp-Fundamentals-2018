﻿namespace BashSoft.Contracts
{
    public interface IDirectoryManager : IDirectoryChanger, IDirectoryCreator, IDirectoryTraverser
    {
    }
}
