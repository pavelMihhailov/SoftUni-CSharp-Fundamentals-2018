﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;

class StudentsRepository
{
    public static bool isDataInitialized = false;

    private static Dictionary<string, Dictionary<string, List<int>>> studentsBycourse;

    public static void InitializeData(string fileName)
    {
        if (!isDataInitialized)
        {
            OutputWriter.WriteMessageonNewLine("Reading data...");
            studentsBycourse = new Dictionary<string, Dictionary<string, List<int>>>();
            ReadData(fileName);
        }
        else
        {
            OutputWriter.DisplayException(ExceptionMessages.DataAlreadyInitializedException);
        }
    }

    private static void ReadData(string fileName)
    {
        string path = SessionData.currentPath + "\\" + fileName;

        if (File.Exists(path))
        {
            string pattern = @"([A-Z][a-zA-Z#+]*_[A-Z][a-z]{2}_\d{4})\s+([A-Z][a-z]{0,3}\d{2}_\d{2,4})\s+(\d+)";
            var rgx = new Regex(pattern);
            string[] allInputLines = File.ReadAllLines(path);
            for (int line = 0; line < allInputLines.Length; line++)
            {
                if (!string.IsNullOrEmpty(allInputLines[line]) && rgx.IsMatch(allInputLines[line]))
                {
                    Match currentMatch = rgx.Match(allInputLines[line]);
                    string courseName = currentMatch.Groups[1].Value;
                    string userName = currentMatch.Groups[2].Value;
                    int studentScoreOnTask;
                    bool hasParsedScore = int.TryParse(currentMatch.Groups[3].Value, out studentScoreOnTask);
                    if (hasParsedScore && studentScoreOnTask >= 0 && studentScoreOnTask <= 100)
                    {
                        if (!studentsBycourse.ContainsKey(courseName))
                        {
                            studentsBycourse.Add(courseName, new Dictionary<string, List<int>>());
                        }

                        if (!studentsBycourse[courseName].ContainsKey(userName))
                        {
                            studentsBycourse[courseName].Add(userName, new List<int>());
                        }

                        studentsBycourse[courseName][userName].Add(studentScoreOnTask);
                    }
                }
            }
        }

        else
        {
            OutputWriter.DisplayException(ExceptionMessages.InvalidPath);
            return;
        }

        isDataInitialized = true;
        OutputWriter.WriteMessageonNewLine("Data read!");
    }

    private static bool IsQueryForCoursePossible(string courseName)
    {
        if (isDataInitialized)
        {
            if (studentsBycourse.ContainsKey(courseName))
            {
                return true;
            }

            OutputWriter.DisplayException(ExceptionMessages.InexistingCourseInDataBase);
        }

        OutputWriter.DisplayException(ExceptionMessages.DataNotInitializedexceptionMessage);
        return false;
    }

    private static bool IsQueryForStudentPossible(string courseName, string studentUserName)
    {
        if (IsQueryForCoursePossible(courseName) && studentsBycourse[courseName].ContainsKey(studentUserName))
        {
            return true;
        }

        OutputWriter.DisplayException(ExceptionMessages.InexistingStudentInDataBase);

        return false;
    }

    public static void GetStudentScoresFromCourse(string courseName, string username)
    {
        if (IsQueryForStudentPossible(courseName, username))
        {
            OutputWriter.PrintStudent(new KeyValuePair<string, List<int>>(username, studentsBycourse[courseName][username]));
        }
    }

    public static void GetAllSudentsFromCourse(string courseName)
    {
        if (IsQueryForCoursePossible(courseName))
        {
            OutputWriter.WriteMessageonNewLine($"{courseName}:");
            foreach (var studentMarksEntry in studentsBycourse[courseName])
            {
                OutputWriter.PrintStudent(studentMarksEntry);
            }
        }
    }

    public static void FilterAndTake(string courseName, string givenFilter, int? studentsToTake = null)
    {
        if (IsQueryForCoursePossible(courseName))
        {
            if (studentsToTake == null)
            {
                studentsToTake = studentsBycourse[courseName].Count;
            }

            RepositoryFilters.FilterAndTake(studentsBycourse[courseName], givenFilter, studentsToTake.Value);
        }
    }

    public static void OrderAndTake(string courseName, string comparison, int? studentsToTake = null)
    {
        if (IsQueryForCoursePossible(courseName))
        {
            if (studentsToTake == null)
            {
                studentsToTake = studentsBycourse[courseName].Count;
            }

            RepositorySorters.OrderAndTake(studentsBycourse[courseName], comparison, studentsToTake.Value);
        }
    }
}

