﻿using System;

namespace BashSoft
{
    public class Launcher
    {
        public static void Main()
        {
            InputReader.StartReadingCommands();
        }
    }
}
